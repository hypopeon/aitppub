<#
.SYNOPSIS
    PowerShell Menu Script to Execute Multiple Installation Scripts with Dependency Management.

.DESCRIPTION
    This script presents a menu to the user with options to execute multiple installation scripts individually or all at once. It ensures that dependencies (like Chocolatey) are handled appropriately.

.NOTES
    Author: Your Name
    Date: 2024-04-27
#>

# Define the list of scripts with their names and URLs
$scripts = @{
    1 = @{
        Name = "Install Office 365"
        Url  = "https://vip.dialectvasteras.se/scripts/install-o365.ps1"
        Dependencies = @()
    }
    2 = @{
        Name = "Install TeamViewer Host"
        Url  = "https://vip.dialectvasteras.se/scripts/install-tvhost.ps1"
        Dependencies = @()
    }
    3 = @{
        Name = "Install Chocolatey"
        Url  = "https://vip.dialectvasteras.se/scripts/install-choco.ps1"
        Dependencies = @()
    }
    4 = @{
        Name = "Install Google Chrome"
        Url  = "https://vip.dialectvasteras.se/scripts/install-chrome.ps1"
        Dependencies = @("Install Chocolatey")
    }
    5 = @{
        Name = "Install Adobe Reader"
        Url  = "https://vip.dialectvasteras.se/scripts/install-adobereader.ps1"
        Dependencies = @("Install Chocolatey")
    }
}

# Function to display the menu
function Show-Menu {
    Clear-Host
    Write-Host "===============================" -ForegroundColor Cyan
    Write-Host "       Script Runner Menu      " -ForegroundColor Cyan
    Write-Host "===============================" -ForegroundColor Cyan
    Write-Host "1. Run All Scripts in Sequence"
    Write-Host "2. Run Script 1: $($scripts[1].Name)"
    Write-Host "3. Run Script 2: $($scripts[2].Name)"
    Write-Host "4. Run Script 3: $($scripts[3].Name)"
    Write-Host "5. Run Script 4: $($scripts[4].Name)"
    Write-Host "6. Run Script 5: $($scripts[5].Name)"
    Write-Host "7. Exit"
    Write-Host ""
}

# Function to execute a single script with dependency handling
function Execute-Script {
    param (
        [string]$ScriptName,
        [string]$ScriptUrl
    )

    Write-Host "Executing '$ScriptName'..." -ForegroundColor Green

    try {
        # Define the local path for the script
        $SafeScriptName = $ScriptName -replace ' ', '_'
        $LocalScriptPath = "$env:TEMP\$SafeScriptName.ps1"

        # Download the script
        Write-Host "Downloading '$ScriptName' from $ScriptUrl..." -ForegroundColor Yellow
        Invoke-WebRequest -Uri $ScriptUrl -OutFile $LocalScriptPath -UseBasicParsing

        # Verify the script was downloaded
        if (Test-Path $LocalScriptPath) {
            Write-Host "Download complete. Executing '$ScriptName'..." -ForegroundColor Green

            # Execute the script
            PowerShell -NoProfile -ExecutionPolicy Bypass -File $LocalScriptPath

            Write-Host "'$ScriptName' executed successfully." -ForegroundColor Green
        }
        else {
            Write-Host "Failed to download '$ScriptName'. Skipping execution." -ForegroundColor Red
        }
    }
    catch {
        Write-Host "An error occurred while executing '$ScriptName': $_" -ForegroundColor Red
    }
    finally {
        # Cleanup: Remove the downloaded script
        if (Test-Path $LocalScriptPath) {
            Remove-Item $LocalScriptPath -Force
            Write-Host "Removed temporary script file: $LocalScriptPath" -ForegroundColor Cyan
        }
    }

    Write-Host ""
}

# Function to execute all scripts in sequence with dependency handling
function Execute-AllScripts {
    # Determine the execution order based on dependencies
    $executionOrder = @(
        "Install Office 365",
        "Install TeamViewer Host",
        "Install Chocolatey",
        "Install Google Chrome",
        "Install Adobe Reader"
    )

    foreach ($scriptName in $executionOrder) {
        $scriptEntry = $scripts.Values | Where-Object { $_.Name -eq $scriptName }
        
        # Handle dependencies
        if ($scriptEntry.Dependencies.Count -gt 0) {
            foreach ($dependency in $scriptEntry.Dependencies) {
                # Check if dependency is already executed or handle accordingly
                # For simplicity, we'll execute dependencies first
                $dependencyEntry = $scripts.Values | Where-Object { $_.Name -eq $dependency }
                if ($dependencyEntry) {
                    Write-Host "Handling dependency: $dependency for $scriptName" -ForegroundColor Magenta
                    Execute-Script -ScriptName $dependencyEntry.Name -ScriptUrl $dependencyEntry.Url
                }
            }
        }

        # Execute the main script
        Execute-Script -ScriptName $scriptEntry.Name -ScriptUrl $scriptEntry.Url
    }
}

# Main loop
do {
    Show-Menu
    $choice = Read-Host "Please enter your choice (1-7)"

    switch ($choice) {
        "1" {
            Execute-AllScripts
            Read-Host "Press Enter to continue..."
        }
        "2" {
            Execute-Script -ScriptName $scripts[1].Name -ScriptUrl $scripts[1].Url
            Read-Host "Press Enter to continue..."
        }
        "3" {
            Execute-Script -ScriptName $scripts[2].Name -ScriptUrl $scripts[2].Url
            Read-Host "Press Enter to continue..."
        }
        "4" {
            Execute-Script -ScriptName $scripts[3].Name -ScriptUrl $scripts[3].Url
            Read-Host "Press Enter to continue..."
        }
        "5" {
            # Before installing Chrome, ensure Chocolatey is installed
            $chocoInstalled = Get-Command choco -ErrorAction SilentlyContinue
            if (-not $chocoInstalled) {
                Write-Host "Chocolatey is not installed. Installing Chocolatey first..." -ForegroundColor Yellow
                Execute-Script -ScriptName $scripts[3].Name -ScriptUrl $scripts[3].Url
            }
            Execute-Script -ScriptName $scripts[4].Name -ScriptUrl $scripts[4].Url
            Read-Host "Press Enter to continue..."
        }
        "6" {
            # Before installing Adobe Reader, ensure Chocolatey is installed
            $chocoInstalled = Get-Command choco -ErrorAction SilentlyContinue
            if (-not $chocoInstalled) {
                Write-Host "Chocolatey is not installed. Installing Chocolatey first..." -ForegroundColor Yellow
                Execute-Script -ScriptName $scripts[3].Name -ScriptUrl $scripts[3].Url
            }
            Execute-Script -ScriptName $scripts[5].Name -ScriptUrl $scripts[5].Url
            Read-Host "Press Enter to continue..."
        }
        "7" {
            Write-Host "Exiting the Script Runner. Goodbye!" -ForegroundColor Cyan
            break
        }
        default {
            Write-Host "Invalid choice. Please select a valid option (1-7)." -ForegroundColor Red
            Read-Host "Press Enter to continue..."
        }
    }
} while ($true)
