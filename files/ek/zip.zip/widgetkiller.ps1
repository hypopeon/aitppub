# Disable specific Taskbar features by modifying registry keys
$registryPaths = @(
    @{
        Path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
        Name = "TaskbarDa"
        Value = 0
        Type  = "DWORD"
    },
    @{
        Path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Search"
        Name = "SearchboxTaskbarMode"
        Value = 0
        Type  = "DWORD"
    },
    @{
        Path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
        Name = "TaskbarMn"
        Value = 0
        Type  = "DWORD"
    },
    @{
        Path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
        Name = "ShowTaskViewButton"
        Value = 0
        Type  = "DWORD"
    }
)

foreach ($reg in $registryPaths) {
    try {
        Set-ItemProperty -Path $reg.Path -Name $reg.Name -Value $reg.Value -Type $reg.Type -Force
        Write-Output "Successfully set $($reg.Name) to $($reg.Value) in $($reg.Path)"
    }
    catch {
        Write-Error "Failed to set $($reg.Name) in $($reg.Path): $_"
    }
}

# Restart Explorer to apply changes
try {
    Stop-Process -Name explorer -Force
    Start-Process explorer
    Write-Output "Explorer restarted successfully."
}
catch {
    Write-Error "Failed to restart Explorer: $_"
}
